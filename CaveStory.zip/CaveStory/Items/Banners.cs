﻿namespace CaveStory.Items
{
    internal class Banners
    {
        internal class GreenCritterBanner
        {
        }
    }
}