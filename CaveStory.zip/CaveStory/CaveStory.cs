using Terraria.ModLoader;

namespace CaveStory
{
	public class CaveStory : Mod
	{
		public CaveStory()
		{
		}

        internal class Projectiles
        {
            internal class NemesisLv3Shot
            {
            }
        }
    }
}